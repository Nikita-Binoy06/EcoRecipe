import React from "react";

export default function Footer() {
  return (
    <footer>
      <p>© 2025 EcoRecipe | Save Food, Save Money!</p>
    </footer>
  );
}
