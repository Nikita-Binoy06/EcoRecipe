import React from "react";

const Rewards = () => {
  return (
    <div>
      <h1>Rewards Page</h1>
      <p>Earn rewards for your contributions!</p>
    </div>
  );
};

export default Rewards;
