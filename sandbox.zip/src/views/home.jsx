import React from "react";

export default function Home() {
  return (
    <div className="page">
      <h1>Welcome to EcoRecipe</h1>
      <p>Find the best recipes for your leftover food!</p>
    </div>
  );
}
