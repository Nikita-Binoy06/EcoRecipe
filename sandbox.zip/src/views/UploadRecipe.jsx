import React from "react";

export default function UploadRecipe() {
  return (
    <div className="page">
      <h1>Upload Your Recipe</h1>
      <p>Share your best leftover recipes with the community!</p>
    </div>
  );
}
