import React from "react";

const Community = () => {
  return (
    <div>
      <h1>Community Page</h1>
      <p>Welcome to the Community section!</p>
    </div>
  );
};

export default Community;
