import React from "react";

export default function Profile() {
  return (
    <div className="page">
      <h1>Your Profile</h1>
      <p>View your saved recipes and uploads.</p>
    </div>
  );
}
