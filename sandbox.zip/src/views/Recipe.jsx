import React from "react";

export default function Recipes() {
  return (
    <div className="page">
      <h1>Discover Recipes</h1>
      <p>Browse and try out user-generated recipes.</p>
    </div>
  );
}
