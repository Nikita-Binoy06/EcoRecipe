import React from "react";
import "./App.css"; // Keep this since styles are in App.css

function App() {
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Welcome to EcoRecipe</h1>
        <p>Reduce waste and cook delicious meals with leftover ingredients.</p>
      </header>

      <main className="home-content">
        <input type="text" placeholder="Enter ingredients..." className="search-bar" />
        <button className="find-recipes-btn">Find Recipes</button>
      </main>

      <footer className="home-footer">
        <p>Join our community and share your recipes!</p>
      </footer>
    </div>
  );
}

export default App;

